package com.example.carbon_emission_tracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarbonEmissionTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarbonEmissionTrackerApplication.class, args);
	}

}
